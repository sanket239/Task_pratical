/
//  Copyright © 2020 task. All rights reserved.
//

import UIKit
import FirebaseAuth
import Firebase
class VerifyCodeVC: UIViewController,AuthUIDelegate {
    var verifymoblie :String?
@IBOutlet weak var OTPVerifyCode: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
verifysetup()
    }
    
    
    @IBAction func btnvertify(_ sender: UIButton) {
        verifysetup()
    }
    func verifysetup(){
        PhoneAuthProvider.provider().verifyPhoneNumber(verifymoblie ?? "", uiDelegate: nil) { (verificationID, error) in
            if let error = error {
                // TODO: show error
                print(error.localizedDescription as Any)
                return
            }
            guard let verifycode = self.OTPVerifyCode.text else {return}
            let credential = PhoneAuthProvider.provider().credential(withVerificationID: verificationID ?? "", verificationCode: verifycode)
            Auth.auth().signIn(with: credential) { (user, error) in
                if error == nil {
                    print(user as Any)
                    var ref: DatabaseReference!
                    
                    ref = Database.database().reference()
                    let userID = Auth.auth().currentUser?.uid
                    ref.child("users").setValue(["name": userID])
                    
                    DispatchQueue.main.async{
                               let viewController =
                                   self.storyboard?.instantiateViewController(withIdentifier: "userVc") as! userVc
                               self.navigationController?.pushViewController(viewController, animated: true)
                           }
                } else{
                    print(error?.localizedDescription as Any)
                }
            }
        }
        
    }
    

}
