//
//  ViewController.swift
//  Task
//  Copyright © 2020 task. All rights reserved.


import UIKit
import FirebaseAuth

class ViewController: UIViewController {
    @IBOutlet weak var textmobile: UITextField!

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btnlogin(_ sender: UIButton) {
        setup()
    }
    func setup(){
      
         DispatchQueue.main.async{
            let viewController =
                self.storyboard?.instantiateViewController(withIdentifier: "VerifyCodeVC") as! VerifyCodeVC
            viewController.verifymoblie = self.textmobile.text
            self.navigationController?.pushViewController(viewController, animated: true)
        }
        
    }

}
