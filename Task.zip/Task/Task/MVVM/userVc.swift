
//  Copyright © 2020 task. All rights reserved.
//
class Model {
    
    var id: String?
    var name: String?
    var mobile :String?
    init(id: String?, name: String?,mobile: String?){
        self.id = id
        self.name = name
        self.mobile = mobile
    }
}
import UIKit
import Firebase
import ContactsUI

class userVc: UIViewController {
    // var ref: DatabaseReference!
    var ref = Database.database().reference()
    var list = [Model]()
    override func viewDidLoad() {
        super.viewDidLoad()
        contactfetch()
        
    }
    func contactfetch(){
        setupfetching()
        self.checkPermissionToDeviceContacts(vc: self) { (status) in
            if status
            {
                DispatchQueue.main.async {
                    let cnPicker = CNContactPickerViewController()
                    cnPicker.delegate = self
                    self.present(cnPicker, animated: true, completion: nil)
                }
            }
        }
    }
    
    
    func setupAddchild(name:String,number:String){
        let key = ref.childByAutoId().key
        
        ref = ref.child("user")
        let data = ["id":key,"mobile": number as String ,"name":name as String]
        ref.child(key ?? "").setValue(data)
        
    }
    func setupfetching(){
        ref = ref.child("user")
        //observing the data changes
        ref.observe(DataEventType.value, with: { (snapshot) in
            let artistObject = snapshot.value as? [String : AnyObject] ?? [:]
             let artistmobile  = artistObject["mobile"] as? String
            let artistId  = artistObject["id"] as? String
            let artistname  = artistObject["name"] as? String
            //creating artist object with model and fetched values
            let modelfetched = Model(id: artistId as? String? ?? "", name: artistname ?? "", mobile: artistmobile ?? "")
            //appending it to list
            self.list.append(modelfetched)
          })
        print(list)
    }
    
}
extension userVc: CNContactPickerDelegate  {
    
    func contactPicker(_ picker: CNContactPickerViewController, didSelect contact: CNContact) {
        
        if contact.givenName.isEmpty == false{
            
        }
        var num :String?
        if contact.phoneNumbers.isEmpty == false {
            let firstPhoneNumber:CNPhoneNumber = contact.phoneNumbers[0].value
            let temp = firstPhoneNumber.stringValue
            var contactNumber = temp.replacingOccurrences(of: "-", with: "")
            
            contactNumber = contactNumber.components(separatedBy: "(").last?.trimmingCharacters(in: .whitespacesAndNewlines) ?? ""
            
            contactNumber = contactNumber.replacingOccurrences(of: "(", with: "")
            
            contactNumber = contactNumber.replacingOccurrences(of: ")", with: "")
            contactNumber = contactNumber.replacingOccurrences(of: " ", with: "")
            num = contactNumber
        }
        
        if list.count != 0{
            list.compactMap { (ovjc)  in
                if  ovjc.mobile == num ?? ""{
                    showAlertView(vc: self, title: "task", msg: "same number alrday add", buttons: ["open", "cancel"], alertType: .alert, alertActionStyle: [.default, .cancel]) { (selectedIndex) in
                        
                    }
                    
                }else{
                    //add data
                    setupAddchild(name: contact.givenName, number: num ?? "")
                }
            }}else{//add data
            setupAddchild(name: contact.givenName, number: num ?? "")
        }
        
    }
    func contactPickerDidCancel(_ picker: CNContactPickerViewController) {
        print("Cancel Contact Picker")
    }
    
}
extension userVc {
    
    func headToSettingsOfPermissions(callBack: @escaping (_ status: Bool) -> Void) {
        CNContactStore().requestAccess(for: .contacts) { response,err  in
            if response {
                callBack(true)
                
            } else {
                callBack(false)
            }
        }
    }
    
    open func checkPermissionToDeviceContacts(vc: UIViewController,callBack: @escaping (_ accessGranted: Bool) -> Void) {
        let authorizationStatus = CNContactStore.authorizationStatus(for: CNEntityType.contacts)
        
        switch authorizationStatus {
        case .authorized, .notDetermined:
            
            self.headToSettingsOfPermissions { (staus) in
                if staus == false {
                    DispatchQueue.main.async {
                        if let settings = URL(string: UIApplication.openSettingsURLString),
                            UIApplication.shared.canOpenURL(settings) {
                            UIApplication.shared.open(settings, options: [:])
                        }
                    }
                }else{
                    callBack(true)
                }
            }
            
        case .denied, .restricted:
            showAlertView(vc: vc, title: "task", msg: "Access Contacts permission", buttons: ["open", "cancel"], alertType: .alert, alertActionStyle: [.default, .cancel]) { (selectedIndex) in
                if selectedIndex == 0{
                    self.headToSettingsOfPermissions { (staus) in
                        if staus == false {
                            if let settings = URL(string: UIApplication.openSettingsURLString),
                                UIApplication.shared.canOpenURL(settings) {
                                UIApplication.shared.open(settings, options: [:])
                            }
                        }else{
                            print("true")
                            callBack(true)
                        }
                    }
                }else{
                    callBack(false)
                }
            }
            
        default:
            callBack(false)
        }
    }
}
extension userVc {
    func showAlertView(vc: UIViewController, title: String?, msg: String?, buttons:[String], alertType: UIAlertController.Style, alertActionStyle: [UIAlertAction.Style], callBack: @escaping (_ selectedIndex: Int) -> Void)
    {
        let alertController = UIAlertController(title: title, message: msg, preferredStyle: alertType)
        // if buttons.count == alertActionStyle.count
        //  {
        for (index, _) in buttons.enumerated()
        {
            
            let alertAction = UIAlertAction(title: buttons[index], style: alertActionStyle.count > index ? alertActionStyle[index] : .default) { (action) in
                callBack(index)
            }
            alertController.addAction(alertAction)
        }
        if alertType == .actionSheet{
            alertController.addAction(UIAlertAction(title: "Cancel", style: .cancel) { (action:UIAlertAction!) in
                print("Cancel")
            })
        }
        
        vc.present(alertController, animated: true)
    }
}
